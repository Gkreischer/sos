# @capacitor/barcode-scanner

Capacitor plugin using Outsystems Barcode libs

## Install

```bash
npm install @capacitor/barcode-scanner
npx cap sync
```

#### Android

The barcode scanner plugin requires a minimum Android SDK target of 26. This is higher than the default that comes with your Capacitor application. You can update this value in your `android/variables.gradle` file.

```gradle
ext {
    minSdkVersion = 26
}
```

Note: Android with `ZXING` scanning library supports all formats, while `MLKIT` supports all except `MAXICODE`, `RSS_14`, `RSS_EXPANDED` and `UPC_EAN_EXTENSION` - using one of these in `hint` will default to scanning any format.

#### iOS

The barcode scanner uses the camera on the device. Ensure you configure the Privacy - Camera Usage Description in your Info.plist file so that your application can access the device's camera.

Note: iOS supports all formats except `MAXICODE` and `UPC_EAN_EXTENSION` - using them in `hint` will default to scanning any format. Also, Apple Vision does not distinguish between `UPC_A` and `EAN_13`, so specifying one of these in `hint` will allow to scan both.

---

## API

<docgen-index>

* [`scanBarcode(...)`](#scanbarcode)
* [Type Aliases](#type-aliases)
* [Enums](#enums)

</docgen-index>

<docgen-api>
<!--Update the source file JSDoc comments and rerun docgen to update the docs below-->

Interface defining the contract for a plugin capable of scanning barcodes.
Requires implementation of the scanBarcode method, which initiates a barcode scan with given options.

Starting in Android targetSdk 36, the scanOrientation parameter has no effect for large screens (e.g. tablets) on Android 16 and higher.
You may opt-out of this behavior in your app by adding `<property android:name="android.window.PROPERTY_COMPAT_ALLOW_RESTRICTED_RESIZABILITY" android:value="true" />` to your `AndroidManifest.xml` inside `<application>` or `<activity>`.
Keep in mind though that this opt-out is temporary and will no longer work for Android 17. Android discourages setting specific orientations for large screens.
Regular Android phones are unaffected by this change.
For more information check the Android docs at https://developer.android.com/about/versions/16/behavior-changes-16#adaptive-layouts

### scanBarcode(...)

```typescript
scanBarcode(options: CapacitorBarcodeScannerOptions) => Promise<CapacitorBarcodeScannerScanResult>
```

| Param         | Type                                                                                      |
| ------------- | ----------------------------------------------------------------------------------------- |
| **`options`** | <code><a href="#capacitorbarcodescanneroptions">CapacitorBarcodeScannerOptions</a></code> |

**Returns:** <code>Promise&lt;<a href="#capacitorbarcodescannerscanresult">CapacitorBarcodeScannerScanResult</a>&gt;</code>

--------------------


### Type Aliases


#### CapacitorBarcodeScannerScanResult

Defines the structure of the result returned from a barcode scan.

<code>{ ScanResult: string; format: <a href="#capacitorbarcodescannertypehint">CapacitorBarcodeScannerTypeHint</a>; }</code>


#### CapacitorBarcodeScannerTypeHint

Extends supported formats from Html5Qrcode with a special 'ALL' option,
indicating support for all barcode types.
Type definition combining <a href="#html5qrcodesupportedformats">Html5QrcodeSupportedFormats</a> and OSBarcodeTypeHintALLOption
to represent the hint for the type of barcode to be scanned.

<code><a href="#html5qrcodesupportedformats">Html5QrcodeSupportedFormats</a> | <a href="#capacitorbarcodescannertypehintalloption">CapacitorBarcodeScannerTypeHintALLOption</a></code>


#### CapacitorBarcodeScannerOptions

Defines the options for configuring a barcode scan.

<code>{ hint: <a href="#capacitorbarcodescannertypehint">CapacitorBarcodeScannerTypeHint</a>; scanInstructions?: string; scanButton?: boolean; scanText?: string; cameraDirection?: <a href="#capacitorbarcodescannercameradirection">CapacitorBarcodeScannerCameraDirection</a>; scanOrientation?: <a href="#capacitorbarcodescannerscanorientation">CapacitorBarcodeScannerScanOrientation</a>; /** * Accessibility label (alternative text) read by screen readers for the cancel button. * When omitted, no accessibility label is set. Has no effect on web. */ cancelButtonAccessibilityLabel?: string; /** * Accessibility label (alternative text) read by screen readers for the torch button when the torch is on. * When omitted, no accessibility label is set. Has no effect on web. */ torchButtonOnAccessibilityLabel?: string; /** * Accessibility label (alternative text) read by screen readers for the torch button when the torch is off. * When omitted, no accessibility label is set. Has no effect on web. */ torchButtonOffAccessibilityLabel?: string; android?: { scanningLibrary?: <a href="#capacitorbarcodescannerandroidscanninglibrary">CapacitorBarcodeScannerAndroidScanningLibrary</a>; }; web?: { showCameraSelection?: boolean; scannerFPS?: number; }; }</code>


### Enums


#### Html5QrcodeSupportedFormats

| Members                 | Value           |
| ----------------------- | --------------- |
| **`QR_CODE`**           | <code>0</code>  |
| **`AZTEC`**             | <code>1</code>  |
| **`CODABAR`**           | <code>2</code>  |
| **`CODE_39`**           | <code>3</code>  |
| **`CODE_93`**           | <code>4</code>  |
| **`CODE_128`**          | <code>5</code>  |
| **`DATA_MATRIX`**       | <code>6</code>  |
| **`MAXICODE`**          | <code>7</code>  |
| **`ITF`**               | <code>8</code>  |
| **`EAN_13`**            | <code>9</code>  |
| **`EAN_8`**             | <code>10</code> |
| **`PDF_417`**           | <code>11</code> |
| **`RSS_14`**            | <code>12</code> |
| **`RSS_EXPANDED`**      | <code>13</code> |
| **`UPC_A`**             | <code>14</code> |
| **`UPC_E`**             | <code>15</code> |
| **`UPC_EAN_EXTENSION`** | <code>16</code> |


#### CapacitorBarcodeScannerTypeHintALLOption

| Members   | Value           |
| --------- | --------------- |
| **`ALL`** | <code>17</code> |


#### CapacitorBarcodeScannerCameraDirection

| Members     | Value          |
| ----------- | -------------- |
| **`BACK`**  | <code>1</code> |
| **`FRONT`** | <code>2</code> |


#### CapacitorBarcodeScannerScanOrientation

| Members         | Value          |
| --------------- | -------------- |
| **`PORTRAIT`**  | <code>1</code> |
| **`LANDSCAPE`** | <code>2</code> |
| **`ADAPTIVE`**  | <code>3</code> |


#### CapacitorBarcodeScannerAndroidScanningLibrary

| Members     | Value                |
| ----------- | -------------------- |
| **`ZXING`** | <code>"zxing"</code> |
| **`MLKIT`** | <code>"mlkit"</code> |

</docgen-api>

## Error handling

The `scanBarcode(...)` method may throw a `CapacitorBarcodeScannerError`.

`CapacitorBarcodeScannerError` extends the native JavaScript `Error` object
and provides a `code` property that can be used to identify the failure reason.

Example:

```ts
import {
  CapacitorBarcodeScanner,
  CapacitorBarcodeScannerError,
  CapacitorBarcodeScannerErrorCode,
} from "@capacitor/barcode-scanner";

try {
  const result = await CapacitorBarcodeScanner.scanBarcode({
    hint: CapacitorBarcodeScannerTypeHint.ALL,
  });

  console.log(result);
} catch (error) {
  if (
    error instanceof CapacitorBarcodeScannerError &&
    error.code === CapacitorBarcodeScannerErrorCode.CAMERA_PERMISSION_DENIED
  ) {
    // Inform the user that camera permission is required.
    // The user must enable camera access in the device settings.
  }
}
```

Available error codes:

| Code                       | Description                                                           |
| -------------------------- | --------------------------------------------------------------------- |
| `CAMERA_PERMISSION_DENIED` | The application does not have permission to access the camera.        |
| `CAMERA_NOT_FOUND`         | No camera device was found.                                           |
| `CAMERA_ALREADY_IN_USE`    | The camera is currently being used by another application or process. |
| `SCAN_CANCELLED`           | The user cancelled the barcode scanning operation.                    |
| `UNSUPPORTED_BROWSER`      | The current browser does not support barcode scanning.                |
| `UNKNOWN`                  | An unknown error occurred while scanning.                             |
